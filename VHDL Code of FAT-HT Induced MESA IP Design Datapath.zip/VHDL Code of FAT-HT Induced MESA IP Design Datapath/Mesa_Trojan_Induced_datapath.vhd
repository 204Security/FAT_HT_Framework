Library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;

entity Mesa_Trojan_Induced_datapath is
Port (Reg_I1,Reg_I2,Reg_I3,Reg_I4 : in std_logic_vector(15 downto 0);--primary inputs
		M1MS,M1DS,M2MS,M2DS,M3MS,M3DS,M4MS,M4DS : in std_logic;--selection lines for 2x1/1x2 mux/demux of Multipliers M1,M2,M3,M4
		M1TMS,M1TDS : in std_logic_vector(1 downto 0);--selection lines for trojan path 4x1/1x4 mux/demux of Multiplier M1
		A2MS,A2DS,A3MS,A3DS : in std_logic;--selection lines for 2x1/1x2 mux/demux of Adders A2,A3
		A1MS,A1DS1,A1DS2 : in std_logic_vector(1 downto 0);--selection lines for normal and trojan path 4x1/1x4 mux/demux of Adder A1
		TTS : in std_logic;--selection line for trojan triggered 2x1/1x2 mux/demux
		L1,L2,L3,L4,L5,L6,L7,L8,L9,L10,L11,L12,L13,L14,L15,L16,L17,L18,L19,L20,L21 : in std_logic;--latch enable pin
		OP0_1,OP0_2,OP_1 : out std_logic_vector(15 downto 0));--final output
end Mesa_Trojan_Induced_datapath;

architecture Structural of Mesa_Trojan_Induced_datapath is

component Adder is
Port (A,B : in std_logic_vector(15 downto 0);
		O : out std_logic_vector (15 downto 0));
end component;

component Multiplier is
Port (A,B : in std_logic_vector(15 downto 0);
		O : out std_logic_vector (15 downto 0));
end component;

component MUX_2x1 is
Port (I0,I1 : in std_logic_vector(15 downto 0);
	   S : in std_logic;
		Yout : out std_logic_vector(15 downto 0));
end component;

component MUX_4x1 is
Port(I0,I1,I2,I3 : in std_logic_vector(15 downto 0);
	  S : in std_logic_vector(1 downto 0);
	  Yout : out std_logic_vector(15 downto 0));
end component;

component DEMUX_1x2 is
Port(Yin : in std_logic_vector(15 downto 0);
	  S : in std_logic;
	  I0,I1: out std_logic_vector(15 downto 0));
end component;

component DEMUX_1x4 is
Port (Yin: in std_logic_vector(15 downto 0);
		S : in std_logic_vector(1 downto 0);
		I0,I1,I2,I3 : out std_logic_vector(15 downto 0));
end component;

component Latch_bh is
port (Lin : in std_logic_vector(15 downto 0);
		Len : in std_logic;
		Lo : out std_logic_vector(15 downto 0));
end component;

Signal s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13,s14,s15,s16,s17,s18,s19,s20,s21,s22,s23,s24,s25,s26,s27,s28,s29,s30,s31,s32,s33,s34,s35,s36,s37,s38,s39,s40,s41,s42,s43,s44,s45,s46,s47,s48,s49,s50,s51,s52,s53,s54,s55,s56,s57,s58,s59,s60,s61,s62,s63,s64,s65,s66,s67,s68,s69,s70,s71,s72,s73 : std_logic_vector(15 downto 0);
Signal f1,f2,f3,f4,f5,f6,f7,f8 : std_logic_vector(15 downto 0);--free signal pins

begin

s23 <= s16 or s18;
s24 <= s17 or s19;
s47 <= s44 or s43;

-------------Multiplier(M1)-------------
L_1:MUX_2x1 port map(I0=>Reg_I1,I1=>s1,S=>M1MS,Yout=>s2);
L_2:MUX_4x1 port map(I0=>Reg_I1,I1=>s3,I2=>s4,I3=>f1,S=>M1TMS,Yout=>s5);--Trojan path mux
L_3:MUX_2x1 port map(I0=>Reg_I1,I1=>s1,S=>M1MS,Yout=>s6);
L_4:MUX_4x1 port map(I0=>Reg_I1,I1=>s3,I2=>s4,I3=>f2,S=>M1TMS,Yout=>s7);--Trojan path mux
L_5:MUX_2x1 port map(I0=>s2,I1=>s5,S=>TTS,Yout=>s8);--Trojan triggered mux
L_6:MUX_2x1 port map(I0=>s6,I1=>s7,S=>TTS,Yout=>s9);--Trojan triggered mux
L_7:Latch_bh Port Map(Lin=>s8,Len=>L1,Lo=>s10);
L_8:Latch_bh Port Map(Lin=>s9,Len=>L2,Lo=>s11);
L_9:Multiplier Port Map(A=>s10,B=>s11,O=>s12);
L_10:Latch_bh Port Map(Lin=>s12,Len=>L3,Lo=>s13);
L_11:DEMUX_1x2 port map(Yin=>s13,S=>TTS,I0=>s14,I1=>s15);--Trojan triggered demux
L_12:DEMUX_1x2 port map(Yin=>s14,S=>M1DS,I0=>s16,I1=>s17);
L_13:DEMUX_1x4 port map(Yin=>s15,S=>M1TDS,I0=>s18,I1=>s19,I2=>s20,I3=>f3);	
-------------Adder(A1)-------------
L_14:MUX_4x1 port map(I0=>s16,I1=>s17,I2=>s45,I3=>f4,S=>A1MS,Yout=>s21);
L_15:MUX_4x1 port map(I0=>s18,I1=>s19,I2=>s20,I3=>f5,S=>A1MS,Yout=>s22);--Trojan path mux
L_16:MUX_4x1 port map(I0=>s23,I1=>s24,I2=>s73,I3=>f6,S=>A1MS,Yout=>s25);
L_17:MUX_2x1 port map(I0=>s21,I1=>s22,S=>TTS,Yout=>s26);--Trojan triggered mux
L_18:Latch_bh Port Map(Lin=>s26,Len=>L4,Lo=>s27);
L_19:Latch_bh Port Map(Lin=>s25,Len=>L5,Lo=>s28);
L_20:Adder Port Map(A=>s27,B=>s28,O=>s29);
L_21:Latch_bh Port Map(Lin=>s29,Len=>L6,Lo=>s30);
L_22:DEMUX_1x2 port map(Yin=>s29,S=>TTS,I0=>s30,I1=>s31);--Trojan triggered demux
L_23:DEMUX_1x4 port map(Yin=>s31,S=>A1DS1,I0=>s1,I1=>s33,I2=>OP0_1,I3=>f7);
L_24:DEMUX_1x4 port map(Yin=>s32,S=>A1DS2,I0=>s3,I1=>s4,I2=>OP0_2,I3=>f8);--Trojan path demux
-------------Multiplier(M4)-------------
L_25:MUX_2x1 port map(I0=>Reg_I4,I1=>s33,S=>M4MS,Yout=>s34);
L_26:MUX_2x1 port map(I0=>Reg_I4,I1=>s33,S=>M4MS,Yout=>s35);
L_27:MUX_2x1 port map(I0=>s34,I1=>Reg_I4,S=>TTS,Yout=>s36);--Trojan triggered mux
L_28:MUX_2x1 port map(I0=>s35,I1=>Reg_I4,S=>TTS,Yout=>s37);--Trojan triggered mux
L_29:Latch_bh Port Map(Lin=>s36,Len=>L7,Lo=>s38);
L_30:Latch_bh Port Map(Lin=>s37,Len=>L8,Lo=>s39);
L_31:Multiplier Port Map(A=>s38,B=>s39,O=>s40);
L_32:Latch_bh Port Map(Lin=>s40,Len=>L9,Lo=>s41);
L_33:DEMUX_1x2 port map(Yin=>s41,S=>TTS,I0=>s42,I1=>s43);--Trojan triggered demux
L_34:DEMUX_1x2 port map(Yin=>s42,S=>M4DS,I0=>s44,I1=>s45);
-------------Adder(A3)-------------
L_35:Latch_bh Port Map(Lin=>s44,Len=>L10,Lo=>s46);
L_36:Latch_bh Port Map(Lin=>s47,Len=>L11,Lo=>s48);
L_37:Adder Port Map(A=>s46,B=>s48,O=>s49);
L_38:Latch_bh Port Map(Lin=>s49,Len=>L12,Lo=>s50);
-------------Multiplier(M3)-------------
L_39:MUX_2x1 port map(I0=>Reg_I3,I1=>s50,S=>M3MS,Yout=>s51);
L_40:MUX_2x1 port map(I0=>Reg_I3,I1=>s50,S=>M3MS,Yout=>s52);
L_41:Latch_bh Port Map(Lin=>s51,Len=>L13,Lo=>s53);
L_42:Latch_bh Port Map(Lin=>s52,Len=>L14,Lo=>s54);
L_43:Multiplier Port Map(A=>s53,B=>s54,O=>s55);
L_44:Latch_bh Port Map(Lin=>s55,Len=>L15,Lo=>s56);
L_45:DEMUX_1x2 port map(Yin=>s56,S=>M3DS,I0=>s57,I1=>s58);
-------------Adder(A2)-------------
L_46:MUX_2x1 port map(I0=>s72,I1=>s58,S=>A2MS,Yout=>s59);
L_47:MUX_2x1 port map(I0=>s72,I1=>s58,S=>A2MS,Yout=>s60);
L_48:Latch_bh Port Map(Lin=>s59,Len=>L16,Lo=>s61);
L_49:Latch_bh Port Map(Lin=>s60,Len=>L17,Lo=>s62);
L_50:Multiplier Port Map(A=>s60,B=>s62,O=>s63);
L_51:Latch_bh Port Map(Lin=>s63,Len=>L18,Lo=>s64);
L_52:DEMUX_1x2 port map(Yin=>s64,S=>A2DS,I0=>s65,I1=>OP_1);
-------------Multiplier(M2)-------------
L_53:MUX_2x1 port map(I0=>Reg_I2,I1=>s65,S=>M2MS,Yout=>s66);
L_54:MUX_2x1 port map(I0=>Reg_I3,I1=>s57,S=>M2MS,Yout=>s67);
L_55:Latch_bh Port Map(Lin=>s66,Len=>L19,Lo=>s68);
L_56:Latch_bh Port Map(Lin=>s67,Len=>L20,Lo=>s69);
L_57:Multiplier Port Map(A=>s68,B=>s69,O=>s70);
L_58:Latch_bh Port Map(Lin=>s70,Len=>L21,Lo=>s71);
L_59:DEMUX_1x2 port map(Yin=>s71,S=>M2MS,I0=>s72,I1=>s73);
end Structural;